#!/bin/bash --login
source ~/.bashrc
set -e conda activate $PROJECT_DIR/env/graph-clusterer
exec "$@"